from django.db import models

# Create your models here.
class Book(models.Model):
    catchoice= [
        ('education', 'Education'),
        ('entertainment', 'Entertainment'),
        ('comics', 'Comics'),
        ('biography', 'Biography'),
        ('history', 'History'),
        ('horror', 'Horror'),
        ('novel', 'Novel'),
        ('fantasy', 'Fantasy'),
        ('thriller', 'Thriller'),
        ('romance', 'Romance'),
        ('scifi','Sci-Fi')
        ]

    Book_Title = models.CharField(max_length=50, blank=True)
    Book_Author = models.CharField(max_length=50, blank=True)
    Book_Description = models.TextField(blank= True)
    Book_Category = models.CharField(max_length=30,choices=catchoice,default='education', blank = True)
    Book_ISBN = models.CharField(max_length=50, blank=True)
    Publisher = models.CharField(max_length=50, blank=True)

    def __str__(self):
        return self.Book_title